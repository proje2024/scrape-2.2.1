package com.example;

import com.example.interfaces.ClickableArea;
import com.example.shapes.SquareClickableArea;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.List;

public class BallDropper extends JPanel implements ActionListener, MouseListener, ComponentListener {
    private List<Ball> balls = new ArrayList<>();
    private Timer timer;
    private ClickableArea clickableArea;
    private int squareSize;

    public BallDropper() {
        this.clickableArea = new SquareClickableArea((int) (Math.min(getWidth(), getHeight()) * 0.8));
        this.addMouseListener(this);
        this.addComponentListener(this);
        this.setDoubleBuffered(true);
        timer = new Timer(15, this);
        timer.start();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        int totalWidth = getWidth();
        int totalHeight = getHeight();
        int offsetX = clickableArea.getOffsetX(totalWidth);
        int offsetY = clickableArea.getOffsetY(totalHeight);

        g.setColor(Color.WHITE);
        g.fillRect(offsetX, offsetY, clickableArea.getWidth(), clickableArea.getHeight());

        for (Ball ball : balls) {
            ball.draw(g, offsetX, offsetY);
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        boolean needRepaint = false;
        for (Ball ball : balls) {
            ball.move();
            if (!ball.isVisible()) needRepaint = true;
        }

        for (int i = 0; i < balls.size(); i++) {
            for (int j = i + 1; j < balls.size(); j++) {
                Ball b1 = balls.get(i);
                Ball b2 = balls.get(j);
                if (b1.checkCollision(b2)) {
                    b1.resolveCollision(b2);
                    needRepaint = true;
                }
            }
        }

        if (needRepaint) repaint();
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        int totalWidth = getWidth();
        int totalHeight = getHeight();
        int offsetX = clickableArea.getOffsetX(totalWidth);
        int offsetY = clickableArea.getOffsetY(totalHeight);

        int clickX = e.getX() - offsetX;
        int clickY = e.getY() - offsetY;

        if (clickableArea.contains(clickX, clickY)) {
            balls.add(new Ball(clickX, clickY, clickableArea.getWidth()));
            repaint();
        }
    }

    @Override
    public void mousePressed(MouseEvent e) {}

    @Override
    public void mouseReleased(MouseEvent e) {}

    @Override
    public void mouseEntered(MouseEvent e) {}

    @Override
    public void mouseExited(MouseEvent e) {}

    @Override
    public void componentResized(ComponentEvent e) {
        int newSize = (int) (Math.min(getWidth(), getHeight()) * 0.8);
        for (Ball ball : balls) {
            ball.updatePosition(squareSize, newSize);
        }
        clickableArea = new SquareClickableArea(newSize);
        squareSize = newSize;
        repaint();
    }

    @Override
    public void componentMoved(ComponentEvent e) {}

    @Override
    public void componentShown(ComponentEvent e) {}

    @Override
    public void componentHidden(ComponentEvent e) {}
}
