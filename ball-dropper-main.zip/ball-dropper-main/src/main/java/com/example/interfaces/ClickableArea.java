package com.example.interfaces;

public interface ClickableArea {
    boolean contains(int x, int y);
    int getWidth();
    int getHeight();
    int getOffsetX(int totalWidth);
    int getOffsetY(int totalHeight);
}
