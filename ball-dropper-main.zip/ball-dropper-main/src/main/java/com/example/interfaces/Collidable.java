package com.example.interfaces;

import com.example.Ball;

public interface Collidable {
    boolean checkCollision(Ball other);
    void resolveCollision(Ball other);
    boolean isVisible();
    void separateBalls(Ball other);
}
