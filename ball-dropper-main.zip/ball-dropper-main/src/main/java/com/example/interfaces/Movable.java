package com.example.interfaces;

public interface Movable {
    void move();
}
