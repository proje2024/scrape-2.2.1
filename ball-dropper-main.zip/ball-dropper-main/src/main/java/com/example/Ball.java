package com.example;

import com.example.interfaces.Collidable;
import com.example.interfaces.Drawable;
import com.example.interfaces.Movable;

import java.awt.Color;
import java.awt.Graphics;
import java.util.Random;

public class Ball implements Movable, Drawable, Collidable {
    private int x, y;
    private int diameter = 20;
    private double yVelocity = 0;
    private double xVelocity = 0;
    private double gravity = 1.96; // Gravity 
    private double elasticity = 0.7; // Elasticity Coefficient
    private double minVelocity = 4.43;
    private double friction = 0.99; // Friction Coefficient
    private int squareSize;
    private boolean visible = true;
    private Color color;

    public Ball(int x, int y, int squareSize) {
        this.x = x;
        this.y = y;
        this.squareSize = squareSize;
        this.color = getRandomColor();
    }

    private Color getRandomColor() {
        Random rand = new Random();
        return new Color(rand.nextInt(256), rand.nextInt(256), rand.nextInt(256));
    }

    @Override
    public void move() {
        if (!visible) return;

        yVelocity += gravity;
        y += yVelocity;
        x += xVelocity;

        // border control
        if (y + diameter > squareSize) {
            y = squareSize - diameter;
            yVelocity = -yVelocity * elasticity;
            if (Math.abs(yVelocity) < minVelocity) {
                yVelocity = 0;
            }
        } else if (y < 0) {
            y = 0;
            yVelocity = -yVelocity * elasticity;
        }

        if (x + diameter > squareSize) {
            x = squareSize - diameter;
            xVelocity = -xVelocity * elasticity;
        } else if (x < 0) {
            x = 0;
            xVelocity = -xVelocity * elasticity;
        }


        xVelocity *= friction;
        yVelocity *= friction;

        if (Math.abs(xVelocity) < 0.01) { 
            xVelocity = 0;
        }
        if (Math.abs(yVelocity) < 0.01) {
            yVelocity = 0;
        }
    }

    @Override
    public void draw(Graphics g, int offsetX, int offsetY) {
        if (!visible) return;
        g.setColor(color);
        g.fillOval(x + offsetX, y + offsetY, diameter, diameter);
    }

    @Override
    public boolean isVisible() {
        return visible;
    }

    @Override
    public boolean checkCollision(Ball other) {
        int dx = this.x - other.x;
        int dy = this.y - other.y;
        int distance = (int) Math.sqrt(dx * dx + dy * dy);
        return distance < this.diameter;
    }

    @Override
    public void resolveCollision(Ball other) {
        double dx = other.x - this.x;
        double dy = other.y - this.y;
        double distance = Math.sqrt(dx * dx + dy * dy);
        if (distance == 0) distance = 1;

        // Calculate overlap and separate balls
        double overlap = 0.5 * (distance - diameter);
        this.x -= overlap * (dx / distance);
        this.y -= overlap * (dy / distance);
        other.x += overlap * (dx / distance);
        other.y += overlap * (dy / distance);

        // Calculate collision angle
        double collisionAngle = Math.atan2(dy, dx);
        double sin = Math.sin(collisionAngle);
        double cos = Math.cos(collisionAngle);

        // Rotate velocities to collision coordinate system
        double thisVelocityX = xVelocity * cos + yVelocity * sin;
        double thisVelocityY = yVelocity * cos - xVelocity * sin;
        double otherVelocityX = other.xVelocity * cos + other.yVelocity * sin;
        double otherVelocityY = other.yVelocity * cos - other.xVelocity * sin;

        // Swap the X components of the velocity
        double temp = thisVelocityX;
        thisVelocityX = otherVelocityX;
        otherVelocityX = temp;

        // Rotate velocities back to original coordinate system
        xVelocity = thisVelocityX * cos - thisVelocityY * sin;
        yVelocity = thisVelocityX * sin + thisVelocityY * cos;
        other.xVelocity = otherVelocityX * cos - otherVelocityY * sin;
        other.yVelocity = otherVelocityX * sin + otherVelocityY * cos;

        // Apply friction
        xVelocity *= friction;
        other.xVelocity *= friction;

        // Stop small movements
        if (Math.abs(xVelocity) < 0.01) {
            xVelocity = 0;
        }
        if (Math.abs(other.xVelocity) < 0.01) {
            other.xVelocity = 0;
        }

        // Ensure balls are separated correctly
        separateBalls(other);
    }

    @Override
    public void separateBalls(Ball other) {
        double dx = other.x - this.x;
        double dy = other.y - this.y;
        double distance = Math.sqrt(dx * dx + dy * dy);
        double minDistance = diameter;

        if (distance < minDistance) {
            double angle = Math.atan2(dy, dx);
            double targetX = this.x + Math.cos(angle) * minDistance;
            double targetY = this.y + Math.sin(angle) * minDistance;
            double ax = (targetX - other.x) * 0.5;
            double ay = (targetY - other.y) * 0.5;

            this.x -= ax;
            this.y -= ay;
            other.x += ax;
            other.y += ay;
        }
    }

    public void updatePosition(int oldSquareSize, int newSquareSize) {
        if (y + diameter > oldSquareSize) {
            y = newSquareSize - diameter;
        }
        if (x + diameter > newSquareSize) {
            x = newSquareSize - diameter;
        }
        this.squareSize = newSquareSize;
    }
}
