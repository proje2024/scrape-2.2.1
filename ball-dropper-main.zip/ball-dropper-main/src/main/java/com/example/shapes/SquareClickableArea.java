package com.example.shapes;

import com.example.interfaces.ClickableArea;

public class SquareClickableArea implements ClickableArea {
    private int size;

    public SquareClickableArea(int size) {
        this.size = size;
    }

    @Override
    public boolean contains(int x, int y) {
        return x >= 0 && x < size && y >= 0 && y < size;
    }

    @Override
    public int getWidth() {
        return size;
    }

    @Override
    public int getHeight() {
        return size;
    }

    @Override
    public int getOffsetX(int totalWidth) {
        return (totalWidth - size) / 2;
    }

    @Override
    public int getOffsetY(int totalHeight) {
        return (totalHeight - size) / 2;
    }
}
