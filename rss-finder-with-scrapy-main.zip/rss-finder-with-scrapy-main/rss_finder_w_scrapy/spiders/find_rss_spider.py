import scrapy
from feedsearch import search
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
from bs4 import BeautifulSoup
from urllib.parse import urlparse
import requests
import os
from rss_finder_w_scrapy.items import RssFinderItem
from dotenv import load_dotenv

load_dotenv()
api_feed_count = 0
lib_feed_count = 0
manual_feed_count = 0


def requests_retry_session(
    retries=5,
    backoff_factor=0.5,
    status_forcelist=(500, 502, 504, 429),
    session=None,
):
    session = session or requests.Session()
    retry = Retry(
        total=retries,
        read=retries,
        connect=retries,
        backoff_factor=backoff_factor,
        status_forcelist=status_forcelist,
    )
    adapter = HTTPAdapter(max_retries=retry)
    session.mount("http://", adapter)
    session.mount("https://", adapter)
    return session


class FindRssSpider(scrapy.Spider):
    name = "find_rss_spider"
    allowed_domains = ["example.com"]
    start_urls = []

    def __init__(self, *args, **kwargs):
        super(FindRssSpider, self).__init__(*args, **kwargs)
        self.load_start_urls()

    def load_start_urls(self):
        base_url_file = os.getenv("BASE_URL_FILE")
        with open(base_url_file, "r") as file:
            self.start_urls = [line.strip() for line in file if line.strip()]

    def parse(self, response):
        base_url = response.url
        self.log(f"{base_url} için RSS linkleri aranıyor...\n")

        api_feeds = self.find_rss_feed_api(base_url)
        for feed in api_feeds:
            yield RssFinderItem(feed_url=feed)

        lib_feeds = self.find_rss_feed_lib(base_url)
        for feed in lib_feeds:
            yield RssFinderItem(feed_url=feed)

        categories = self.find_category_links(response)
        manual_feeds = self.generate_rss_links(base_url, categories)
        for feed in manual_feeds:
            yield RssFinderItem(feed_url=feed)

    def find_rss_feed_api(self, url):
        global api_feed_count
        valid_feeds = []
        try:
            api_endpoint = f"https://feedsearch.dev/api/v1/search?url={url}&info=true&favicon=false&opml=false&skip_crawl=false"
            response = requests_retry_session().get(api_endpoint)
            if response.status_code == 200:
                feeds = response.json()
                feed_urls = [feed["url"] for feed in feeds]
                for feed_url in feed_urls:
                    if self.is_valid_feed(feed_url):
                        self.log(f"Feedsearch API ile bulundu: {feed_url}")
                        valid_feeds.append(feed_url)
                api_feed_count += len(valid_feeds)
                return valid_feeds
            else:
                self.log("Feedsearch API kullanarak RSS linkleri bulunamadı.")
                return []
        except Exception as e:
            self.log(f"Feedsearch API kullanarak RSS linkleri bulunurken hata oluştu: {e}")
            return []

    def find_rss_feed_lib(self, url):
        global lib_feed_count
        try:
            feeds = search(url, info=True)
            feed_urls = []
            for feed in feeds:
                feed_url = feed.url
                if self.is_valid_feed(feed_url):
                    feed_urls.append(feed_url)
                    self.log(f"Feedsearch kütüphanesi ile bulundu: {feed_url}")
            lib_feed_count += len(feed_urls)
            return feed_urls
        except Exception as e:
            self.log(f"Feedsearch kütüphanesi kullanarak RSS linkleri bulunurken hata oluştu: {e}")
            return []

    def find_category_links(self, response):
        category_links = set()

        for link in response.css('a::attr(href)').getall():
            if 'cat=' in link or 'category/' in link or 'categorie/' in link or 'section/' in link or 'magazine/' in link or 'ad/' in link or 'jobs/' in link:
                category_links.add(link if link.startswith('http') else response.urljoin(link))
                
        return list(category_links)

    def generate_rss_links(self, base_url, categories):
        global manual_feed_count
        feed_urls = set()
        for category in categories:
            if "cat=" in category:
                rss_url = f"{category}&feed=rss2"
            elif (
                "category/" in category
                or "categorie/" in category
                or "section/" in category
                or "magazine/" in category
                or "ad/" in category
                or "jobs/" in category
            ):
                rss_url = f"{category.rstrip('/')}/feed"
            else:
                continue
            if self.is_valid_feed(rss_url):
                feed_urls.add(rss_url)
                self.log(f"Manuel yöntemle bulundu: {rss_url}")
        manual_feed_count += len(feed_urls)
        return list(feed_urls)

    def is_valid_feed(self, url):
        parsed_url = urlparse(url)
        referer = f"{parsed_url.scheme}://{parsed_url.netloc}"
        
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
            'Referer': referer,
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.9',
            'Connection': 'keep-alive',
            'DNT': '1',
            'Upgrade-Insecure-Requests': '1',
        }
        try:
            request = scrapy.Request(url, headers=headers, callback=self.check_feed_response)
            self.crawler.engine.schedule(request, self)
        except Exception as e:
            self.log(f"RSS kontrolü sırasında hata oluştu: {e}")
            return False

    def check_feed_response(self, response):
        if "<rss" in response.text or "<feed" in response.text or "application/rss+xml" in response.text or "application/atom+xml" in response.text:
            return True

        soup = BeautifulSoup(response.text, 'html.parser')
        for link in soup.find_all('link', href=True):
            if 'type' in link.attrs:
                type_attr = link['type']
                if "application/rss+xml" in type_attr or "application/atom+xml" in type_attr:
                    return True
        return False
