# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html


# useful for handling different item types with a single interface
from itemadapter import ItemAdapter
import os
from dotenv import load_dotenv

load_dotenv()
class RssFinderPipeline:
    def open_spider(self, spider):
        self.output_path = os.getenv("OUTPUT_RSS_LINK_PATH")
        self.existing_urls = set()
        if self.output_path and os.path.exists(self.output_path):
            with open(self.output_path, "r") as file:
                self.existing_urls = set(line.strip() for line in file if line.strip())
        else:
            with open(self.output_path, "w") as file:
                file.write("")

    def process_item(self, item, spider):
        if self.output_path:
            if item['feed_url'] not in self.existing_urls:
                with open(self.output_path, "a") as file:
                    file.write(f"{item['feed_url']}\n")
                spider.log(f"Yeni RSS linki eklendi: {item['feed_url']}")
                self.existing_urls.add(item['feed_url'])
            else:
                spider.log(f"RSS linki zaten mevcut: {item['feed_url']}")
        else:
            spider.log("Output RSS link path is not set.")
        return item
