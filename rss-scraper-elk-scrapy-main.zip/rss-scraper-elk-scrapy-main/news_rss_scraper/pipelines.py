import os
import json
import logging
from elasticsearch import Elasticsearch
from cryptography.fernet import Fernet
import yaml

class JsonWriterPipeline:
    def __init__(self):
        self.file = None
        self.base_output_path = os.getenv("OUTPUT_PATH").rsplit(".", 1)[0]
        self.output_index = 1
        self.file_size_limit = 50 * 1024 * 1024  # 50 MB limit

    def open_spider(self):
        self.file = open(
            f"{self.base_output_path}_{self.output_index}.json", "w", encoding="utf-8"
        )

    def close_spider(self):
        if self.file:
            self.file.close()

    def process_item(self, item):
        line = json.dumps(dict(item), ensure_ascii=False) + "\n"
        self.file.write(line)
        self.file.flush()

        if os.stat(self.file.name).st_size > self.file_size_limit:
            self.file.close()
            self.output_index += 1
            self.file = open(
                f"{self.base_output_path}_{self.output_index}.json",
                "w",
                encoding="utf-8",
            )

        return item


class ElasticsearchPipeline:
    def __init__(self):
        config_path = "/app/config/config.yaml"
        with open(config_path) as file:
            config = yaml.safe_load(file)
        self.decrypt_passwords(config)
        es_config = config["elasticsearch"]
        self.es = Elasticsearch(
            hosts=[f"{es_config['host']}:{es_config['port']}"],
            basic_auth=(es_config["user"], es_config["password"]),
            verify_certs=False,
        )
        self.log_file_path = os.getenv("ELK_LOG_PATH")
        self.logger = logging.getLogger("ElasticsearchPipeline")
        self.configure_logging()

    def process_item(self, item):
        try:
            response = self.es.index(index=item['_index'], id=item['_id'], document=dict(item['_source']))
            if response.get('result') == 'created':
                self.logger.info(f"Successfully indexed item: {item['_id']}")
            else:
                self.logger.warning(f"Item {item['_id']} already existed or was updated.")
        except Exception as e:
            self.logger.error(f"Failed to index item {item['_id']}: {e}")
        return item

    def configure_logging(self):
        
        handler = logging.FileHandler(self.log_file_path)
        formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        handler.setFormatter(formatter)
        self.logger.addHandler(handler)
        self.logger.setLevel(logging.DEBUG)

    def decrypt_passwords(self, data):
        with open("/app/config/config.key", "rb") as key_file:
            key = key_file.read()
        fernet = Fernet(key)
        for k, v in data.items():
            if isinstance(v, dict):
                self.decrypt_passwords(v)
            elif ("password" in k) or ("key" in k):
                decrypted_password = fernet.decrypt(v.encode()).decode()
                data[k] = decrypted_password
