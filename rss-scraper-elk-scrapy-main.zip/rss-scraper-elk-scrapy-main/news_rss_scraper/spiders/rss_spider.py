import scrapy
from scrapy.http import Request
import feedparser
from bs4 import BeautifulSoup
from dateutil import parser as date_parser
import pytz
from datetime import datetime
import os
from dotenv import load_dotenv
from news_rss_scraper.items import RssFeedItem


class RssSpider(scrapy.Spider):
    name = "rss_spider"

    def __init__(self, *args, **kwargs):
        super(RssSpider, self).__init__(*args, **kwargs)
        self.start_time = datetime.now(pytz.utc)

    def start_requests(self):
        load_dotenv()
        self.output_path = os.getenv("OUTPUT_PATH")
        self.base_output_path = self.output_path.rsplit(".", 1)[0]
        self.output_index = 1

        with open(os.getenv("RSS_LINK_PATH"), "r") as file:
            rss_links = [line.strip() for line in file.readlines()]

        for url in rss_links:
            yield Request(url, self.parse_rss, meta={"rss_url": url})

    def parse_rss(self, response):
        feed = feedparser.parse(response.text)
        for entry in feed.entries:
            yield from self.process_entry(entry, response.meta["rss_url"])

    def process_entry(self, entry, rss_url):
        if not hasattr(entry, 'title') or not hasattr(entry, 'link'):
            self.logger.info(
                f"Skipping entry due to missing title or link. RSS URL: {rss_url}"
            )
            return

        try:
            if "published" in entry:
                created_date = date_parser.parse(entry.published)
            elif "pubDate" in entry:
                created_date = date_parser.parse(entry.pubDate)
            else:
                self.logger.info(
                    f"No date found for entry. Title: {entry.title} Link: {rss_url}"
                )
                return
            created_date = created_date.astimezone(pytz.utc)
        except Exception as e:
            self.logger.error(
                f"Error parsing date. Title: {entry.title} Link: {rss_url}: {e}"
            )
            return

        content = entry.get('content', '')
        if isinstance(content, list) and 'value' in content[0]:
            content = content[0]['value']
        else:
            content = getattr(entry, 'summary', '')

        content = entry.get('content', [{}])[0].get('value', '') if isinstance(entry.get('content', ''), list) else entry.get('summary', '')
        media_links = set(self.extract_media_links(content))

       
        if "media_content" in entry:
            media_links.update(media["url"] for media in entry.get("media_content", []))
        if "enclosures" in entry:
            media_links.update(enclosure["href"] for enclosure in entry.get("enclosures", []))
        if hasattr(entry, 'enclosure'):
            media_links.update(enclosure["href"] for enclosure in getattr(entry, 'enclosure', []))
        if "content_encoded" in entry:
            media_links.update(self.extract_media_links(entry.get("content_encoded", '')))

        media_links = list(media_links)
        item = RssFeedItem(
            _index="news",
            _id=entry.title,
            _score=1,
            _source={
                "date": created_date.isoformat(),
                "title": entry.title,
                "content": self.extract_text(content),
                "link": entry.link,
                "media_links": media_links,
            },
        )
        yield item

    def extract_media_links(self, html_content):
        soup = BeautifulSoup(html_content, "html.parser")
        media_links = []

        for img in soup.find_all('img'):
            src = img.get('src')
            if src and not src.startswith(('data:', 'javascript:', '#')):
                media_links.append(src)

        for source in soup.find_all('source'):
            src = source.get('src')
            if src and not src.startswith(('data:', 'javascript:', '#')):
                media_links.append(src)

        return media_links
    
    def extract_text(self, html_content):
        soup = BeautifulSoup(html_content, "html.parser")
  
        for li in soup.find_all("li"):
            li.insert_before("\n- ")
        
        for p in soup.find_all("p"):
            p.insert_before("\n")
            p.insert_after("\n")
        
        for header in soup.find_all(["h1", "h2", "h3", "h4", "h5", "h6"]):
            header.insert_before("\n")
            header.insert_after("\n")
        
        for br in soup.find_all("br"):
            br.insert_after("\n")
      
        text = soup.get_text(separator=" ", strip=True)
        
        return text

    

    def closed(self, reason):
        end_time = datetime.now(pytz.utc)
        duration = end_time - self.start_time
        hours, remainder = divmod(duration.total_seconds(), 3600)
        minutes, seconds = divmod(remainder, 60)
        self.logger.info(
            f"Program çalışma süresi: {int(hours)} saat {int(minutes)} dakika {int(seconds)} saniye"
        )
        print(
            f"Program çalışma süresi: {int(hours)} saat {int(minutes)} dakika {int(seconds)} saniye"
        )
