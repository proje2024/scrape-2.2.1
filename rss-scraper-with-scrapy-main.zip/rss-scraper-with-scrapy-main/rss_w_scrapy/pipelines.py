# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html


# useful for handling different item types with a single interface
import os
import json
import scrapy

class JsonWriterPipeline:
    def __init__(self):
        self.file = None
        self.base_output_path = os.getenv('OUTPUT_PATH').rsplit('.', 1)[0]
        self.output_index = 1
        self.file_size_limit = 50 * 1024 * 1024  # 50 MB sınır
        self.lang_file = None
        self.lang_output_path = self.base_output_path + "_lang.json"
        self.seen_combinations = set()

    def open_spider(self, spider):
        self.file = open(f"{self.base_output_path}_{self.output_index}.json", 'w', encoding='utf-8')
        self.lang_file = open(self.lang_output_path, 'w', encoding='utf-8')

    def close_spider(self, spider):
        if self.file:
            self.file.close()
        if self.lang_file:
            self.lang_file.close()

    def process_item(self, item, spider):
        item_copy = dict(item)
        if 'rss_link' in item_copy:
            del item_copy['rss_link']
        line = json.dumps(item_copy, ensure_ascii=False) + "\n"
        self.file.write(line)
        self.file.flush()
        
        if os.stat(self.file.name).st_size > self.file_size_limit:
            self.file.close()
            self.output_index += 1
            self.file = open(f"{self.base_output_path}_{self.output_index}.json", 'w', encoding='utf-8')
        
        if 'metadata' in item and 'lang' in item['metadata']:
            lang = item['metadata']['lang']
            rss_link = item['rss_link']
            combination = (lang, rss_link)
            if combination not in self.seen_combinations:
                lang_line = json.dumps({'lang': lang, 'rss_link': rss_link}, ensure_ascii=False) + "\n"
                self.lang_file.write(lang_line)
                self.lang_file.flush()
                self.seen_combinations.add(combination)
        
        return item
