import scrapy
from scrapy.utils.project import get_project_settings
from scrapy.http import Request
import feedparser
from bs4 import BeautifulSoup
import hashlib
from urllib.parse import urlparse
import os
from dotenv import load_dotenv
from dateutil import parser as date_parser
import pytz
from datetime import datetime
from langdetect import detect
import re
from rss_w_scrapy.items import RssFeedItem


class RssSpider(scrapy.Spider):
    name = "rss_spider"

    def __init__(self, *args, **kwargs):
        super(RssSpider, self).__init__(*args, **kwargs)
        self.start_time = datetime.now(pytz.utc)

    def start_requests(self):
        load_dotenv()
        self.output_path = os.getenv("OUTPUT_PATH")
        self.base_output_path = self.output_path.rsplit(".", 1)[0]
        self.output_index = 1
        self.unique_identifiers = set()

        with open(os.getenv("RSS_LINK_PATH"), "r") as file:
            rss_links = [line.strip() for line in file.readlines()]

        for url in rss_links:
            yield Request(url, self.parse_rss, meta={"rss_url": url})

    def parse_rss(self, response):
        feed = feedparser.parse(response.text)
        for entry in feed.entries:
            yield from self.process_entry(entry, response.meta["rss_url"])

    def process_entry(self, entry, rss_url):
        try:
            if "published" in entry:
                created_date = date_parser.parse(entry.published)
            elif "pubDate" in entry:
                created_date = date_parser.parse(entry.pubDate)
            else:
                self.logger.info(
                    f"No date found for entry. Title:{entry.title} Link: {rss_url}"
                )
                return
            created_date = created_date.astimezone(pytz.utc)
        except Exception as e:
            self.logger.error(
                f"Error parsing date. Title: {entry.title} Link: {rss_url}: {e}"
            )
            return

        identifier = self.generate_unique_id(
            f"{entry.title}-{created_date.isoformat()}"
        )
        if identifier in self.unique_identifiers:
            return
        self.unique_identifiers.add(identifier)

        try:
            lang = detect(entry.title)
        except:
            lang = "unknown"

        media_links = set()
        if "content" in entry:
            media_links.update(self.extract_media_links(entry.content[0].value))
        if "media_content" in entry:
            media_links.update([media["url"] for media in entry.media_content])
        if "enclosures" in entry:
            media_links.update([enclosure["href"] for enclosure in entry.enclosures])
        if "content_encoded" in entry:
            media_links.update(self.extract_media_links(entry.content_encoded))

        media_links = list(media_links)

        item = RssFeedItem(
            type=self.determine_type(entry),
            source=self.extract_domain(rss_url),
            provider="rss",
            identifier=identifier,
            created_date=created_date.isoformat(),
            scraped_date=datetime.now(pytz.utc).isoformat(),
            metadata={
                "content": f"Başlık: {entry.title} \n {getattr(entry, 'summary', '')}",
                "author": getattr(entry, "author", "unknown"),
                "media_links": media_links,
                "lang": lang,
                "country": self.extract_country_from_url(rss_url),
            },
            rss_link=rss_url,
        )
        yield item

    def extract_media_links(self, html_content):
        soup = BeautifulSoup(html_content, "html.parser")
        media_links = []

        for tag in soup.find_all(src=True):
            if tag.name != "script":
                src = tag["src"]
                if src:
                    media_links.append(src)
        return media_links

    def generate_unique_id(self, identifier):
        sha_signature = hashlib.sha256(identifier.encode()).hexdigest()
        return sha_signature

    def extract_domain(self, url):
        parsed_url = urlparse(url)
        domain = parsed_url.netloc
        if domain.startswith("www."):
            domain = domain[4:]
        return domain.split(".")[0]

    def determine_type(self, entry):
        if "forum" in entry.link:
            return "forum"
        else:
            return "haberler"

    def extract_country_from_url(self, url):
        match = re.search(r"\.([a-z]{2})\/", url)
        if match:
            country_code = match.group(1)
            return country_code
        return "unknown"

    def closed(self, reason):
        end_time = datetime.now(pytz.utc)
        duration = end_time - self.start_time
        hours, remainder = divmod(duration.total_seconds(), 3600)
        minutes, seconds = divmod(remainder, 60)
        self.logger.info(
            f"Program çalışma süresi: {int(hours)} saat {int(minutes)} dakika {int(seconds)} saniye"
        )
        print(
            f"Program çalışma süresi: {int(hours)} saat {int(minutes)} dakika {int(seconds)} saniye"
        )
