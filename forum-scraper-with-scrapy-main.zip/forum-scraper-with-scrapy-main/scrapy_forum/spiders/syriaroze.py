import scrapy
from scrapy import signals
from scrapy.exceptions import NotConfigured
import time
from datetime import datetime
import re
import hashlib
from langdetect import detect
from dateutil import parser as date_parser
import pytz
from scrapy_forum.items import ForumItem


class SyriarozeSpider(scrapy.Spider):
    name = "syriaroze_spider"
    allowed_domains = ["syriaroze.com"]
    start_urls = ["https://www.syriaroze.com"]

    def __init__(self, *args, **kwargs):
        super(SyriarozeSpider, self).__init__(*args, **kwargs)
        self.start_time = None

    @classmethod
    def from_crawler(cls, crawler, *args, **kwargs):
        spider = super(SyriarozeSpider, cls).from_crawler(crawler, *args, **kwargs)
        crawler.signals.connect(spider.spider_opened, signal=signals.spider_opened)
        crawler.signals.connect(spider.spider_closed, signal=signals.spider_closed)
        return spider

    def spider_opened(self, spider):
        self.start_time = time.time()
        self.logger.info(
            "********************************Program Başladı********************************\n: %s",
            spider.name,
        )

    def spider_closed(self, spider):
        end_time = time.time()
        elapsed_time = end_time - self.start_time
        elapsed_hours, rem = divmod(elapsed_time, 3600)
        elapsed_minutes, elapsed_seconds = divmod(rem, 60)
        self.logger.info("Spider closed: %s", spider.name)
        self.logger.info(
            "Elapsed Time: %d hours, %d minutes, %d seconds",
            elapsed_hours,
            elapsed_minutes,
            elapsed_seconds,
        )
        print(
            f"***************************Program Sonlandı********************\n: {spider.name}"
        )
        print(
            f"*********************Çalışma Süresi*********************\n: {int(elapsed_hours)} hours, {int(elapsed_minutes)} minutes, {int(elapsed_seconds)} seconds"
        )

    def generate_unique_id(self, identifier):
        sha_signature = hashlib.sha256(identifier.encode()).hexdigest()
        return sha_signature

    def parse(self, response):

        categories = response.xpath(
            '//tr[@class="category-header"]/td/a[@class="category"]'
        )
        for category in categories:  # kategorileri dolaşma
            category_title = category.xpath("text()").get()
            category_url = response.urljoin(category.xpath("@href").get())
            yield scrapy.Request(
                url=category_url,
                callback=self.parse_category,
                meta={"category_title": category_title},
            )

    def parse_category(self, response):
        category_title = response.meta["category_title"]

        subforums = response.xpath('//a[@class="forum-title"]')
        for subforum in subforums:  # subforum dolaşma
            subforum_title = subforum.xpath("text()").get()
            subforum_url = response.urljoin(subforum.xpath("@href").get())
            yield scrapy.Request(
                url=subforum_url,
                callback=self.parse_subforum,
                meta={
                    "category_title": category_title,
                    "subforum_title": subforum_title,
                },
            )

    def parse_subforum(self, response):
        category_title = response.meta["category_title"]
        subforum_title = response.meta["subforum_title"]

        topics = response.xpath('//a[@class="topic-title js-topic-title"]')
        for topic in topics:  # topikleri dolaşma
            topic_title = topic.xpath("text()").get()
            topic_url = response.urljoin(topic.xpath("@href").get())
            yield scrapy.Request(
                url=topic_url,
                callback=self.parse_topic,
                meta={
                    "category_title": category_title,
                    "subforum_title": subforum_title,
                    "topic_title": topic_title,
                },
            )

        # Sayfalama
        # Sayfalama "/page1, /page2" gibi yapılmaktadır
        current_page_number = response.url.split("/")[-1]
        if "page" in current_page_number:
            current_page_number = int(current_page_number.replace("page", ""))
        else:
            current_page_number = 1

        next_page_number = current_page_number + 1
        base_url = response.url.split("/page")[0]
        next_page_url = f"{base_url}/page{next_page_number}"

        next_page_link = response.xpath(
            '//a[@class="js-pagenav-button js-pagenav-next-button b-button b-button--secondary js-shrink-event-child"][@data-page][@tabindex="0"]'
        )
        if next_page_link:
            yield scrapy.Request(
                url=next_page_url,
                callback=self.parse_subforum,
                meta={
                    "category_title": category_title,
                    "subforum_title": subforum_title,
                },
            )

    def parse_topic(self, response):
        category_title = response.meta["category_title"]
        subforum_title = response.meta["subforum_title"]
        topic_title = response.meta["topic_title"]

        posts = response.xpath(
            '//li[contains(@class, "b-post") and contains(@class, "js-post") and contains(@class, "js-comment-entry__parent") and contains(@class, "h-restore--on-preview") and contains(@class, "b-post--text")]'
        )
        if posts:
            for post in posts:  # postları dolaşma
                created_date_str = (
                    post.xpath(
                        './/div[@class="b-post__timestamp"]/time/@datetime'
                    ).get()
                    or "unknown"
                )
                content = (
                    " ".join(
                        post.xpath(
                            './/div[contains(@class, "js-post__content-text")]/descendant-or-self::*/text()'
                        ).extract()
                    ).strip()
                    or ""
                )
                author = (
                    post.xpath(
                        './/div[@class="author h-text-size--14"]/strong/text()'
                    ).get()
                    or "unknown"
                )
                avatar_image = (
                    post.xpath(
                        './/a[contains(@class, "b-avatar b-avatar--m b-avatar--thread")]/img/@src'
                    ).get()
                    or ""
                )
                register_date = (
                    post.xpath(
                        './/li[@class="b-userinfo__additional-info"]/span/text()'
                    ).get()
                    or "unknown"
                )
                img_sources = response.xpath(
                    '//div[contains(@class, "b-post__body")]//img/@src'
                ).extract()

                if avatar_image:
                    avatar_image = f"https://www.syriaroze.com/{avatar_image}"

                media_links = (
                    [avatar_image] + img_sources if avatar_image else img_sources
                )

                if author != "unknown":
                    author = (
                        author.strip()
                        .replace("\r", "")
                        .replace("\n", "")
                        .replace("\t", "")
                    )

                if content:
                    content = (
                        content.strip()
                        .replace("\r", "")
                        .replace("\n", "")
                        .replace("\t", "")
                    )

                if created_date_str != "unknown":
                    created_date = date_parser.parse(created_date_str)
                    created_date = created_date.astimezone(pytz.utc).isoformat()
                else:
                    created_date = "unknown"

                try:
                    if content.strip():
                        lang = detect(content)
                    elif topic_title.strip():
                        lang = detect(topic_title)
                    elif subforum_title.strip():
                        lang = detect(subforum_title)
                    else:
                        lang = detect(category_title)
                except:
                    lang = "unknown"

                forum_item = ForumItem(
                    type="forum",
                    source="syriaroze",
                    provider="scrapy",
                    identifier=self.generate_unique_id(
                        f"{topic_title}-{created_date_str}"
                    ),
                    created_date=created_date,
                    scraped_date=datetime.now(pytz.utc).isoformat(),
                    metadata={
                        "content": f"Başlık: {topic_title} \n {content}",
                        "author": author,
                        "media_links": media_links,
                        "lang": lang,
                        "country": "sy",
                        "category_title": category_title,
                        "subforum_title": subforum_title,
                        "topic_title": topic_title,
                    },
                )

                yield forum_item

        # Sayfalama
        # Sayfalama "/page1, /page2" gibi yapılmaktadır
        current_page_number = response.url.split("/")[-1]
        if "page" in current_page_number:
            current_page_number = int(current_page_number.replace("page", ""))
        else:
            current_page_number = 1

        next_page_number = current_page_number + 1
        base_url = response.url.split("/page")[0]
        next_page_url = f"{base_url}/page{next_page_number}"

        next_page_link = response.xpath(
            '//a[@class="js-pagenav-button js-pagenav-next-button b-button b-button--secondary js-shrink-event-child"][@data-page][@tabindex="0"]'
        )
        if next_page_link:
            yield scrapy.Request(
                url=next_page_url,
                callback=self.parse_topic,
                meta={
                    "category_title": category_title,
                    "subforum_title": subforum_title,
                    "topic_title": topic_title,
                },
            )
