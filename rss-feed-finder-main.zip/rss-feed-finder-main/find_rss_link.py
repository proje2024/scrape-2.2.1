import requests
from feedsearch import search
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
from bs4 import BeautifulSoup
import os
from dotenv import load_dotenv
from urllib.parse import urlparse
import time

start_time = time.time()
load_dotenv()
api_feed_count = 0
lib_feed_count = 0
manual_feed_count = 0


def requests_retry_session(
    retries=5,
    backoff_factor=0.5,
    status_forcelist=(500, 502, 504, 429),
    session=None,
):
    session = session or requests.Session()
    retry = Retry(
        total=retries,
        read=retries,
        connect=retries,
        backoff_factor=backoff_factor,
        status_forcelist=status_forcelist,
    )
    adapter = HTTPAdapter(max_retries=retry)
    session.mount("http://", adapter)
    session.mount("https://", adapter)
    return session


def find_rss_feed_api(url):
    global api_feed_count
    valid_feeds = []
    try:
        api_endpoint = "https://feedsearch.dev/api/v1/search?url={}&info=true&favicon=false&opml=false&skip_crawl=false".format(url)
        response = requests_retry_session().get(api_endpoint)
        if response.status_code == 200:
            feeds = response.json()
            feed_urls = [feed["url"] for feed in feeds]
            for feed_url in feed_urls:
                if is_valid_feed(feed_url):
                    print("Found with Feedsearch API: {}".format(feed_url))
                    valid_feeds.append(feed_url)
            api_feed_count += len(valid_feeds)
            return valid_feeds
        else:
            print("No RSS links found using Feedsearch API.")
            return []
    except Exception as e:
        print("Error finding RSS links using Feedsearch API: {}".format(e))
        return []


def find_rss_feed_lib(url):
    global lib_feed_count
    try:
        feeds = search(url, info=True)
        feed_urls = []
        for feed in feeds:
            feed_url = feed.url
            if is_valid_feed(feed_url):
                feed_urls.append(feed_url)
                print("Found with Feedsearch library: {}".format(feed_url))
        lib_feed_count += len(feed_urls)
        return feed_urls
    except Exception as e:
        print("Error finding RSS links using Feedsearch library: {}".format(e))
        return []


# manual RSS discovery by inspecting the site
def find_category_links(url):
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.9',
        'Connection': 'keep-alive',
        'DNT': '1',
        'Upgrade-Insecure-Requests': '1',
    }
    try:
        response = requests_retry_session().get(url, headers=headers, timeout=30)
        response.raise_for_status()
        soup = BeautifulSoup(response.content, 'html.parser')
        category_links = set()

        for link in soup.find_all('a', href=True):
            href = link['href']
            if 'cat=' in href or 'category/' in href or 'categorie/' in href or 'section/' in href or 'magazine/' in href or 'ad/' in href or 'jobs/' in href:
                category_links.add(href if href.startswith('http') else url.rstrip('/') + '/' + href.lstrip('/'))
                
        return list(category_links)
    except requests.exceptions.RequestException as e:
        print("Error finding category links: {}".format(e))
        return []


# validating the guessed RSS links 
def is_valid_feed(url):
    parsed_url = urlparse(url)
    referer = "{}://{}".format(parsed_url.scheme, parsed_url.netloc)
    
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
        'Referer': referer,
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.9',
        'Connection': 'keep-alive',
        'DNT': '1',
        'Upgrade-Insecure-Requests': '1',
    }
    try:
        response = requests_retry_session().get(url, headers=headers, timeout=30)
        response.raise_for_status()
        
        if "<rss" in response.text or "<feed" in response.text or "application/rss+xml" in response.text or "application/atom+xml" in response.text:
            return True
        
        soup = BeautifulSoup(response.content, 'html.parser')
        for link in soup.find_all('link', href=True):
            if 'type' in link.attrs:
                type_attr = link['type']
                if "application/rss+xml" in type_attr or "application/atom+xml" in type_attr:
                    return True
        return False
    except requests.exceptions.RequestException as e:
        print("Error checking RSS: {}".format(e))
        return False


def generate_rss_links(categories):
    global manual_feed_count
    feed_urls = set()
    for category in categories:
        if "cat=" in category:
            rss_url = "{}&feed=rss2".format(category)
        elif (
            "category/" in category
            or "categorie/" in category
            or "section/" in category
            or "magazine/" in category
            or "ad/" in category
            or "jobs/" in category
        ):
            rss_url = "{}/feed".format(category.rstrip('/'))
        else:
            continue
        if is_valid_feed(rss_url):
            feed_urls.add(rss_url)
            print("Found manually: {}".format(rss_url))
    manual_feed_count += len(feed_urls)
    return list(feed_urls)


def write_to_file(urls):
    output_path = os.getenv("OUTPUT_RSS_LINK_PATH")
    if os.path.exists(output_path):
        with open(output_path, "r") as file:
            existing_urls = set(file.read().splitlines())
    else:
        existing_urls = set()

    new_urls = set(urls) - existing_urls

    if new_urls:
        with open(output_path, "a") as file:
            for url in new_urls:
                file.write(url + "\n")
    else:
        print("No new RSS links to write.")


def read_base_urls_from_file(file_path):
    with open(file_path, "r") as file:
        return [line.strip() for line in file if line.strip()]


def main(base_urls):
    all_feeds = set()

    for base_url in base_urls:
        print("\nSearching for RSS links for {}...\n".format(base_url))

        api_feeds = find_rss_feed_api(base_url)
        all_feeds.update(api_feeds)

        lib_feeds = find_rss_feed_lib(base_url)
        all_feeds.update(lib_feeds)

        categories = find_category_links(base_url)
        manual_feeds = generate_rss_links(categories)
        all_feeds.update(manual_feeds)

    write_to_file(list(all_feeds))
  
    end_time = time.time()
    elapsed_time = end_time - start_time
    hours, rem = divmod(elapsed_time, 3600)
    minutes, seconds = divmod(rem, 60)

    print("\n***********RSS Link Report***********\n")
    print("Found with Feedsearch API: {}".format(api_feed_count))
    print("Found with Feedsearch library: {}".format(lib_feed_count))
    print("Found manually: {}".format(manual_feed_count))
    print("Total: {}".format(len(all_feeds)))
    print("Elapsed time: {} hours {} minutes {} seconds".format(int(hours), int(minutes), int(seconds)))


if __name__ == "__main__":
    load_dotenv()
    base_url_file = os.getenv("BASE_URL_FILE")
    base_urls = read_base_urls_from_file(base_url_file)
    main(base_urls)
